package day4_jdbc;

class Hellojdbc
{
	public static void main(String args[])
	{
		System.out.println("Hello world");
	}
}