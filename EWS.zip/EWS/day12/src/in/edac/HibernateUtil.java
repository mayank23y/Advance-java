package in.edac;

public class HibernateUtil {

}
