package in.edac;

import org.hibernate.cfg.Configuration;

public class HibernateDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 new Configuration().configure().buildSessionFactory();
		 System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiii bhopal wali bhabhi");


	}

}
