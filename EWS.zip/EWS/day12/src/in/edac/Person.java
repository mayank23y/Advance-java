package in.edac;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Person implements Serializable {

	private static final long serialVersionID =1L;
	@Id
	private int id;
	private String firstName;
	private String middleName1;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName1;
	}
	public void setMiddleName(String middleName) {
		this.middleName1 = middleName;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	private String lastname;
	private String middleName;
}
