package in.edac.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.edac.dao.AddNotesDao;
import in.edac.dao.Notes;

/**
 * Servlet implementation class EditNotesServlet
 */
@WebServlet("/EditNotesServlet")
public class EditNotesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String idd=request.getParameter("id");
			int id = Integer.parseInt(idd);
			String title = request.getParameter("title");
			String content = request.getParameter("content");
			
			
			Notes notes=new Notes();
				notes.setId(id);
				notes.setTitle(title);
				notes.setContent(content);
				
				AddNotesDao dao = new AddNotesDao();
			dao.updateUser(notes);
			response.sendRedirect("EditNotesServlet");
			} catch (Exception e) {
				e.printStackTrace();
				response.sendRedirect("EditNotesServlet");
			}
	}
		
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
