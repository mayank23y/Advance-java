package in.edac.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AddNotesDao {

private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public  void createUser(Notes notes){
	Session session	= sessionFactory.openSession();
	Transaction tx  = session.beginTransaction();
	
	session.save(notes);
	tx.commit();
	session.close();
}
	public List<Notes>  showNotes(){
		Session session	= sessionFactory.openSession();
		Transaction tx  = session.beginTransaction();
		
		String sql = "SELECT * FROM NOTES";
		List<Notes> list = session.createNativeQuery(sql, Notes.class).getResultList();
		
		tx.commit();
		session.close();
		return list ;
	}
	

	public  void deleteNote(Notes notes) {
		
		Session session =  sessionFactory.openSession();
		session.beginTransaction();
		
		session.delete(notes);
		
		session.getTransaction().commit();
		session.close();
	}
	
	public  void updateUser(Notes notes) {
		
		Session session =  sessionFactory.openSession();
		session.beginTransaction();
		
		session.update(notes);
		
		session.getTransaction().commit();
		session.close();
	}
	
	
}
