package in.edac.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class RegisterDao {
	private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public static void createUser(User user){
	Session session	= sessionFactory.openSession();
	Transaction tx  = session.beginTransaction();
	
	session.save(user);
	tx.commit();
	session.close();
	}

}
